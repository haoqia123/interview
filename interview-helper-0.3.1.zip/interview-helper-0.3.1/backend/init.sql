-- AI Interview Helper Database Initialization
-- 初始化数据库脚本

-- 确保数据库使用UTF8编码
SET client_encoding = 'UTF8';

-- 创建扩展（如果需要）
-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 数据库初始化完成
SELECT 'AI Interview Helper Database Initialized' AS status;